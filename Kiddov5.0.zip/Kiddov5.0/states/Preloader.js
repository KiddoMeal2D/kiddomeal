
BasicGame.Preloader = function (game) {

	this.background = null;
	this.preloadBar = null;
    this.titleText=null;
	this.ready = false;

};

BasicGame.Preloader.prototype = {

	preload: function () {

		//	These are the assets we loaded in Boot.js
		//	A nice sparkly background and a loading progress bar
	//	this.background = this.add.sprite(0, 0, 'bgload');
		this.background = this.add.sprite(this.world.centerX,this.world.centerY, 'bgload');
		this.background.anchor.setTo(0.5,0.5);
		this.background.width = this.game.width;
		this.background.height = this.game.height;

		this.titleText = this.add.sprite(this.world.centerX,this.world.centerY, 'kiddo');
		this.titleText.anchor.setTo(0.5,0.5);
		this.titleText.scale.setTo(0.25,0.25);
		this.preloadBar = this.add.sprite(this.world.centerX,this.world.centerY, 'loading');
		this.preloadBar.anchor.setTo(0.5,0.5);
		//	This sets the preloadBar sprite as a loader sprite.
		//	What that does is automatically crop the sprite from 0 to full-width
		//	as the files below are loaded in.
		this.load.setPreloadSprite(this.preloadBar);

		//UI Kiddo Menu
		this.load.image('bgkiddo','assets/kiddo-bg-menu/kiddo-bg2.png');
		this.load.image('logokiddo','assets/kiddo-bg-menu/kiddo-logo.png');
		this.load.image('startbtn','assets/kiddo-bg-menu/kiddo-start-btn.png');
		this.load.image('howbtn','assets/kiddo-bg-menu/kiddo-how-to-play-btn.png');
		this.load.image('achievebtn','assets/kiddo-bg-menu/kiddo-achievements-btn.png');
		this.load.image('creditsbtn','assets/kiddo-bg-menu/kiddo-credits-btn.png');
		this.load.image('quitbtn','assets/kiddo-bg-menu/kiddo-quit-btn.png');

    },

	create: function () {
	//this.state.start('MainMenu');
//  this.state.start('MainMenu');

	},

	update: function () {

		//	You don't actually need to do this, but I find it gives a much smoother game experience.
		//	Basically it will wait for our audio file to be decoded before proceeding to the MainMenu.
		//	You can jump right into the menu if you want and still play the music, but you'll have a few
		//	seconds of delay while the mp3 decodes - so if you need your music to be in-sync with your menu
		//	it's best to wait for it to decode here first, then carry on.
		
		//	If you don't have any music in your game then put the game.state.start line into the create function and delete
		//	the update function completely.
	this.ready = true;
	this.state.start('MainMenu');
	}

};
