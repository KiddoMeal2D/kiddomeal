
BasicGame.Play = function (game) {
//this.startBG;
  //  this.startPrompt;
 //   this.ready = false;

};

BasicGame.Play.prototype = {
	create: function () {
		//Game Sounds
	this.bgplaya = this.add.sprite(this.game.world.centerX,this.game.world.centerY, 'bgplay');
	this.bgplaya.anchor.setTo(0.5,0.5);
	this.bgplaya.width = this.game.width;
	this.bgplaya.height = this.game.height;
		
	this.grplaya = this.add.sprite(this.game.world.centerX,this.game.world.centerY,'grplay');	
//	this.grplaya.width = this.game.width;
//	this.grplaya.anchor.setTo(2,1.5);
//	this.grplaya.scale.setTo(0.1,0.5);	
	},
	update: function() {
	
	}
};