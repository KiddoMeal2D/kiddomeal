
BasicGame.MainMenu = function (game) {
//this.startBG;
  //  this.startPrompt;
 //	this.ready = false;


};

BasicGame.MainMenu.prototype = {
	preload: function () {
		this.load.image('bgplay','assets/kiddo-bg-game-world/bg-world1.png');
		this.load.image('grplay','assets/kiddo-bg-game-world/ground1.png');
	},


	create: function () {
		//Game Sounds

		//UI Kiddo Menu
	this.backgroundbg = this.add.sprite(this.game.world.centerX,this.game.world.centerY, 'bgkiddo');
	this.backgroundbg.anchor.setTo(0.5,0.5);
	this.backgroundbg.width = this.game.width;
	this.backgroundbg.height = this.game.height;

	this.titleText = this.add.sprite(this.game.world.centerX,this.game.world.centerY, 'logokiddo');
	this.titleText.anchor.setTo(0.5,1.50);
	this.titleText.scale.setTo(0.22,0.22);
	this.startb = this.add.button(this.game.world.centerX,this.game.world.centerY, 'startbtn',this.startGame,this);
	this.startb.anchor.setTo(0.5,1.5);
	this.startb.scale.setTo(0.25,0.25);
	this.howb = this.add.button(this.game.world.centerX,this.game.world.centerY, 'howbtn');
	this.howb.anchor.setTo(0.5,0.2);
	this.howb.scale.setTo(0.25,0.25);
	this.achieveb = this.add.button(this.game.world.centerX,this.game.world.centerY, 'achievebtn');
	this.achieveb.anchor.setTo(0.5,-1);
	this.achieveb.scale.setTo(0.25,0.25);
	this.creditsb = this.add.button(this.game.world.centerX,this.game.world.centerY, 'creditsbtn');
	this.creditsb.anchor.setTo(0.5,-2.3);
	this.creditsb.scale.setTo(0.25,0.25);
	this.quitb = this.add.button(this.game.world.centerX,this.game.world.centerY, 'quitbtn');
	this.quitb.anchor.setTo(0.5,-3.5);
	this.quitb.scale.setTo(0.25,0.25);

	},

	update: function () {

	},

	startGame: function () {
		this.state.start('Play');
	}

};
